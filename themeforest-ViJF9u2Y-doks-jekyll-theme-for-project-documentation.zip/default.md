---
# Page settings
layout: default
keywords:
comments: false

# Hero section
title: Page title
description: Page description

# Author box
author:
    title: About Author
    title_url: '#'
    external_url: true
    description: Author description

# Micro navigation
micro_nav: true

# Page navigation
page_nav:
    prev:
        content: Previous page
        url: '#'
    next:
        content: Next page
        url: '#'
---

Write your markdown here ...
